package hadooptest;
// ex1_part3_3
import java.io.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
//import java.nio.file.Path;
import java.util.Scanner;
import java.util.Set;
import java.util.StringTokenizer;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.BlockLocation;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.LocatedFileStatus;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.RemoteIterator;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;



public class EX1_4 {
    static FileSystem hdfs = null;
    static Scanner scan = new Scanner(System.in);
    
    public static void init() throws IOException{
        Configuration conf = new Configuration();
        conf.set("fs,defaultFS","hdfs://localhost:9000");
        System.setProperty("HADOOP_USER_NAME","hadoop");
        hdfs = FileSystem.get(conf);

    }
    
    public static class childParentMapper
    		extends Mapper<Object, Text, Text, Text> {
    		private Text name1 = new Text();
    		private Text name2 = new Text();
    		private Text name3 = new Text();
    		private Text name4 = new Text();
		public void map(Object key, Text value, Context context)
		        throws IOException, InterruptedException {
			// map
			//(name,child)
			//(name,father)
			String nameChildParent = new String(value.toString());
			String[] name = nameChildParent.split(" ");
			System.out.println(name);
			name1.set(name[0]);
			name2.set("2 " + name[1]);
			name3.set("1 " + name[0]);
			name4.set(name[1]);
			context.write(name1,name2);		// (name, 2 father)
			context.write(name4,name3);		// (name, 1 child)
			

		}
	}
	
	public static class childGrandReducer
	    	extends Reducer<Text,Text,Text,Text> {
		
			private Text childName = new Text();
			private Text grandName = new Text();
		public void reduce(Text key, Iterable<Text> values, Context context)
		        throws IOException, InterruptedException {
			// child - name - father --> child-grandFather
				List<String> childList = new ArrayList<>();
				List<String> grandList  = new ArrayList<>();
				for(Text line : values)
				{
					String midStr = line.toString();
					System.out.println(midStr);
					String[] relation = midStr.split(" ");
					if(relation[0].equals("1"))
					{
						childList.add(relation[1]);
						System.out.println("Success add " + relation[1]);
					}
					else
						grandList.add(relation[1]);
					
				}
				
				
				for(String child: childList)
				{
					childName.set(child);
					for(String grand : grandList)
					{
						grandName.set(grand);
						context.write(childName, grandName);
					}
				}
					
		}
	}
    
    
    
    public static void main(String[] args) throws Exception {
        init();
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "childGrandp");

        job.setJarByClass(EX1_4.class);
        job.setMapperClass(childParentMapper.class);
        job.setReducerClass(childGrandReducer.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        FileInputFormat.addInputPath(job, new Path("/ex1/test4/childParent.txt"));
        FileOutputFormat.setOutputPath(job, new Path("/ex1/test4/result"));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }

}
