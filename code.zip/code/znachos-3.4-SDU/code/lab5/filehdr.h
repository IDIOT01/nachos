// filehdr.h 
//	Data structures for managing a disk file header.  
//
//	A file header describes where on disk to find the data in a file,
//	along with other information about the file (for instance, its
//	length, owner, etc.)
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"

#ifndef FILEHDR_H
#define FILEHDR_H

#include "disk.h"
#include "bitmap.h"

#define NumDirect 	((SectorSize - 2 * sizeof(int)) / sizeof(int))
#define MaxFileSize 	(NumDirect * SectorSize)

// The following class defines the Nachos "file header" (in UNIX terms,  
// the "i-node"), describing where on disk to find all of the data in the file.
// The file header is organized as a simple table of pointers to
// data blocks. 
//
// The file header data structure can be stored in memory or on disk.
// When it is on disk, it is stored in a single sector -- this means
// that we assume the size of this data structure to be the same
// as one disk sector.  Without indirect addressing, this
// limits the maximum file length to just under 4K bytes.
//
// There is no constructor; rather the file header can be initialized
// by allocating blocks for the file (if it is a new file), or by
// reading it from disk.

class FileHeader {
  public:
    bool Allocate(BitMap *bitMap, int fileSize);// 初始化文件头，包括为文件数据在磁盘上分配空间
    void Deallocate(BitMap *bitMap);   // 取消分配此文件的数据块

    void FetchFrom(int sectorNumber);  // 从磁盘中初始化文件头
    void WriteBack(int sectorNumber);  // 将文件头的修改写回磁盘

    int ByteToSector(int offset);   // 将文件中的偏移量转换为包含该字节的磁盘扇区

    int FileLength();       // 返回文件的长度（以字节为单位）

    void Print();       // 打印文件的内容。

  private:
    int numBytes;     // 文件中的字节数
    int numSectors;     // 文件中的数据扇区数
    int dataSectors[NumDirect];   // 文件中每个数据块的磁盘扇区号
};


#endif // FILEHDR_H
