// bitmap.h 
//	Data structures defining a bitmap -- an array of bits each of which
//	can be either on or off.
//
//	Represented as an array of unsigned integers, on which we do
//	modulo arithmetic to find the bit we are interested in.
//
//	The bitmap can be parameterized with with the number of bits being 
//	managed.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#ifndef BITMAP_H
#define BITMAP_H

#include "copyright.h"
#include "utility.h"
#include "openfile.h"

// Definitions helpful for representing a bitmap as an array of integers
#define BitsInByte 	8
#define BitsInWord 	32

// The following class defines a "bitmap" -- an array of bits,
// each of which can be independently set, cleared, and tested.
//
// Most useful for managing the allocation of the elements of an array --
// for instance, disk sectors, or main memory pages.
// Each bit represents whether the corresponding sector or page is
// in use or free.

class BitMap {
  public:
    BitMap(int nitems);    // 初始化Bitmap，有“nitems”位，最初所有位均清除。
    ~BitMap();             // 释放Bitmap
    
    void Mark(int which);  // 设置第which位
    void Clear(int which); // 清除第which位
    bool Test(int which);  // 第which位设置了吗？
    int Find();            // 返回一个清除的位的号码，并附带副作用，将该位设置。如果没有可用位，则返回-1。
    int NumClear();        // 返回Bitmap中清除的位数

    void Print();          // 打印Bitmap的内容
    
    // FILESYS需要，在那里需要读取和写入Bitmap到文件
    void FetchFrom(OpenFile *file);  // 从磁盘中读取内容
    void WriteBack(OpenFile *file); // 写入内容到磁盘

  private:
    int numBits;            // Bitmap中的位数
    int numWords;           // Bitmap存储的字数
                           // （如果numBits不是字位数的倍数，则四舍五入）
    unsigned int *map;      // 位存储
};


#endif // BITMAP_H
