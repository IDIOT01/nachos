#include "syscall.h"

int main() {
	Exec("exit");
	Exit(1);
}