#include "syscall.h"

int main() {
	Time();
	Exit(0);
}
